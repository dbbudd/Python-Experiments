#!/usr/bin/python
print "Content-type: text/html"
print

#import the libraries
import cgi
import cgitb; cgitb.enable()
import sqlite3
import sys


print("<html>")
print("<head>")
print("<title>PokeCGI</title>")
print("<meta http-equiv='Content-Type' content='text/html;charset=utf-8'>")
print("</head>")
print("<body>")

def search_form():
    print("<h1>SEARCH DATABASE</h1>")
    print("""
          <form id='search_database' action='search_new_query.py' method='GET'>
          
          <p>
          <label>Search:</label><br/>
          <input type='text' name='Search_Query'>
          </p>
          <p>
          <label>Choose the Table:</label><br/>
          <select name='Choose_Table'>
          <option>Locations</option>
          <option>Pokedex</option>
          <option>Trainers</option>
          </select>
          </p>
          
          <p>
          <input type='submit' value='Submit' />
          </p>
          
          </form>
          """)


search_form()

print("</body>")
print("</html>")